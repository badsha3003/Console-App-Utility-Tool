﻿using System;
using System.IO;
using Serilog;

class Program
{
    static void Main(string[] args)
    {

        Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .WriteTo.File("logs/Mylog.txt", rollingInterval: RollingInterval.Day)
            .CreateLogger();


        Log.Information("Welcome to the File Management Utility");

        while (true)
        {
            Console.WriteLine("\nChoose an option:");
            Console.WriteLine("1. List files in a directory");
            Console.WriteLine("2. Rename a file");
            Console.WriteLine("3. Move a file");
            Console.WriteLine("4. Delete a file");
            Console.WriteLine("5. Exit");

            var choice = Console.ReadLine();
            Log.Information("User selected option {Choice}", choice);

            switch (choice)
            {
                case "1":
                    ListFiles();
                    break;
                case "2":
                    RenameFile();
                    break;
                case "3":
                    MoveFile();
                    break;
                case "4":
                    DeleteFile();
                    break;
                case "5":
                    Log.Information("Exiting application...");
                    return;
                default:
                    Log.Warning("Invalid option selected by the user: {Choice}", choice);
                    break;
            }
        }
    }


    static void ListFiles()
    {
        Console.Write("Enter the directory path: ");
        string path = Console.ReadLine();
        Log.Information("Listing files in directory: {Path}", path);

        if (Directory.Exists(path))
        {
            var files = Directory.GetFiles(path);
            Log.Information("Found {FileCount} files in directory {Path}", files.Length, path);

            Console.WriteLine("\nFiles in directory:");
            foreach (var file in files)
            {
                Console.WriteLine(Path.GetFileName(file));
                Log.Information("File: {FileName}", Path.GetFileName(file));
            }
        }
        else
        {
            Log.Error("Directory does not exist: {Path}", path);
            Console.WriteLine("Directory does not exist.");
        }
    }


    static void RenameFile()
    {
        Console.Write("Enter the directory path: ");
        string path = Console.ReadLine();
        Log.Information("Renaming file in directory: {Path}", path);

        if (Directory.Exists(path))
        {
            Console.Write("Enter the filename to rename: ");
            string oldName = Console.ReadLine();
            string oldFilePath = Path.Combine(path, oldName);

            if (File.Exists(oldFilePath))
            {
                Console.Write("Enter the new filename: ");
                string newName = Console.ReadLine();
                string newFilePath = Path.Combine(path, newName);

                try
                {
                    File.Move(oldFilePath, newFilePath);
                    Log.Information("File renamed from {OldName} to {NewName}", oldName, newName);
                    Console.WriteLine($"File renamed to {newName}");
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Error renaming file: {OldName} to {NewName}", oldName, newName);
                    Console.WriteLine($"Error renaming file: {ex.Message}");
                }
            }
            else
            {
                Log.Error("File does not exist: {OldFilePath}", oldFilePath);
                Console.WriteLine("File does not exist.");
            }
        }
        else
        {
            Log.Error("Directory does not exist: {Path}", path);
            Console.WriteLine("Directory does not exist.");
        }
    }

    static void MoveFile()
    {
        Console.Write("Enter the source directory path: ");
        string sourcePath = Console.ReadLine();
        Log.Information("Moving file from source directory: {SourcePath}", sourcePath);

        if (Directory.Exists(sourcePath))
        {
            Console.Write("Enter the filename to move: ");
            string fileName = Console.ReadLine();
            string sourceFilePath = Path.Combine(sourcePath, fileName);

            if (File.Exists(sourceFilePath))
            {
                Console.Write("Enter the destination directory path: ");
                string destinationPath = Console.ReadLine();

                if (Directory.Exists(destinationPath))
                {
                    string destinationFilePath = Path.Combine(destinationPath, fileName);

                    try
                    {
                        File.Move(sourceFilePath, destinationFilePath);
                        Log.Information("File {FileName} moved from {SourcePath} to {DestinationPath}", fileName, sourcePath, destinationPath);
                        Console.WriteLine($"File moved to {destinationPath}");
                    }
                    catch (Exception ex)
                    {
                        Log.Error(ex, "Error moving file from {SourcePath} to {DestinationPath}", sourcePath, destinationPath);
                        Console.WriteLine($"Error moving file: {ex.Message}");
                    }
                }
                else
                {
                    Log.Error("Destination directory does not exist: {DestinationPath}", destinationPath);
                    Console.WriteLine("Destination directory does not exist.");
                }
            }
            else
            {
                Log.Error("File does not exist: {SourceFilePath}", sourceFilePath);
                Console.WriteLine("File does not exist.");
            }
        }
        else
        {
            Log.Error("Source directory does not exist: {SourcePath}", sourcePath);
            Console.WriteLine("Source directory does not exist.");
        }
    }



    static void DeleteFile()
    {
        Console.Write("Enter the directory path: ");
        string path = Console.ReadLine();
        Log.Information("Deleting file in directory: {Path}", path);

        if (Directory.Exists(path))
        {
            Console.Write("Enter the filename to delete: ");
            string fileName = Console.ReadLine();
            string filePath = Path.Combine(path, fileName);

            if (File.Exists(filePath))
            {
                Console.Write($"Are you sure you want to delete {fileName}? (y/n): ");
                string confirmation = Console.ReadLine().ToLower();

                if (confirmation == "y")
                {
                    try
                    {
                        File.Delete(filePath);
                        Log.Information("File {FileName} deleted from {Path}", fileName, path);
                        Console.WriteLine("File deleted.");
                    }
                    catch (Exception ex)
                    {
                        Log.Error(ex, "Error deleting file: {FilePath}", filePath);
                        Console.WriteLine($"Error deleting file: {ex.Message}");
                    }
                }
                else
                {
                    Log.Information("File deletion canceled: {FileName}", fileName);
                    Console.WriteLine("File deletion canceled.");
                }
            }
            else
            {
                Log.Error("File does not exist: {FilePath}", filePath);
                Console.WriteLine("File does not exist.");
            }
        }
        else
        {
            Log.Error("Directory does not exist: {Path}", path);
            Console.WriteLine("Directory does not exist.");
        }
    }
}